rootProject.name = "com.example.financial-manager-ktor"
